#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import sys
import subprocess


if len(sys.argv) != 3:
    print "./processConvert2TFile.py inputDir outputDir"
    sys.exit()


inputDir = sys.argv[1]
outputDir = sys.argv[2]
filelist = os.listdir( inputDir )
filelist.sort()
file

for file in filelist:
    if file.find( ".dat" ) == -1:
        continue
    inputfile = os.path.join( inputDir, file )
    outputfile = os.path.join( outputDir, file.replace( ".dat", ".root") )
    subprocess.call( "./Convert2TFile " + inputfile + " " + outputfile, shell=True)
